package org.firstinspires.ftc.teamcode.teleop;

import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.IMU;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

@TeleOp(name = "NguyenLong", group = "TeleOp")
public class NguyenLong extends LinearOpMode {

    private DcMotor frontLeft;
    private DcMotor frontRight;
    private DcMotor backLeft;
    private DcMotor backRight;

    private IMU imu;

    @Override
    public void runOpMode() {

        // Anh xa dong co theo code goc cua ban
        frontRight = hardwareMap.get(DcMotor.class, "dr0");
        frontLeft  = hardwareMap.get(DcMotor.class, "dr1");
        backLeft   = hardwareMap.get(DcMotor.class, "dr2");
        backRight  = hardwareMap.get(DcMotor.class, "dr3");

        // Giu nguyen chieu quay trong code goc
        frontRight.setDirection(DcMotor.Direction.FORWARD);
        frontLeft.setDirection(DcMotor.Direction.REVERSE);
        backLeft.setDirection(DcMotor.Direction.REVERSE);
        backRight.setDirection(DcMotor.Direction.FORWARD);

        // Phanh khi tha joystick
        frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        // Khoi tao IMU tich hop tren REV Control Hub
        imu = hardwareMap.get(IMU.class, "imu");

        // Gia dinh logo REV huong len, cong USB huong ve phia truoc
        RevHubOrientationOnRobot orientation =
                new RevHubOrientationOnRobot(
                        RevHubOrientationOnRobot.LogoFacingDirection.UP,
                        RevHubOrientationOnRobot.UsbFacingDirection.FORWARD
                );

        imu.initialize(new IMU.Parameters(orientation));

        telemetry.addLine("NguyenLong - Field-Centric");
        telemetry.addLine("IMU da khoi tao");
        telemetry.addLine("Cho bam PLAY");
        telemetry.update();

        waitForStart();

        if (isStopRequested()) {
            return;
        }

        // Dat huong ban dau thanh 0 do
        imu.resetYaw();

        boolean previousReset = false;

        while (opModeIsActive()) {

            // Doc joystick
            double y = -gamepad1.left_stick_y;
            double x = gamepad1.left_stick_x;
            double turn = gamepad1.right_stick_x;

            // Deadzone
            if (Math.abs(y) < 0.05) y = 0;
            if (Math.abs(x) < 0.05) x = 0;
            if (Math.abs(turn) < 0.05) turn = 0;

            // Doc goc huong tu IMU
            double heading = imu
                    .getRobotYawPitchRollAngles()
                    .getYaw(AngleUnit.RADIANS);

            // Bam START de reset goc IMU
            boolean currentReset = gamepad1.start;

            if (currentReset && !previousReset) {
                imu.resetYaw();
                heading = 0.0;
            }

            previousReset = currentReset;

            // Chuyen joystick sang Field-Centric
            double rotX =
                    x * Math.cos(heading)
                            + y * Math.sin(heading);

            double rotY =
                    -x * Math.sin(heading)
                            + y * Math.cos(heading);

            // Tinh cong suat 4 banh Mecanum
            double fl = rotY + rotX + turn;
            double fr = rotY - rotX - turn;
            double bl = rotY - rotX + turn;
            double br = rotY + rotX - turn;

            // Chuan hoa cong suat
            double max = Math.max(
                    1.0,
                    Math.max(
                            Math.max(Math.abs(fl), Math.abs(fr)),
                            Math.max(Math.abs(bl), Math.abs(br))
                    )
            );

            fl /= max;
            fr /= max;
            bl /= max;
            br /= max;

            // Gui cong suat den dung dong co
            frontLeft.setPower(fl);   // dr1
            frontRight.setPower(fr);  // dr0
            backLeft.setPower(bl);    // dr2
            backRight.setPower(br);  // dr3

            // Hien thi thong tin
            telemetry.addData("IMU Yaw (do)", "%.1f",
                    Math.toDegrees(heading));
            telemetry.addData("dr0 - truoc phai", "%.2f", fr);
            telemetry.addData("dr1 - truoc trai", "%.2f", fl);
            telemetry.addData("dr2 - sau trai", "%.2f", bl);
            telemetry.addData("dr3 - sau phai", "%.2f", br);
            telemetry.update();
        }
    }
}